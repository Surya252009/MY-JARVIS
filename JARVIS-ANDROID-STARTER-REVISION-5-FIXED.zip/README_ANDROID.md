# J.A.R.V.I.S. Native Android Project

## Just A Rather Very Intelligent System
Inspired by Tony Stark's personal AI assistant. Native Android starter application built with Kotlin, Jetpack Compose, Material 3, Android Room Database, and a backend-proxied Gemini chat client.

---

### Prerequisites
1. **Android Studio**: Ladybug / Koala or newer (2024.2+).
2. **JDK**: Java 17 or Java 21.
3. **Android SDK**: API 35 (Android 15) with minSdk 26 (Android 8.0 Oreo).
4. **Target Device**: Android Tablet (landscape & portrait optimized) or Android Phone.

---

### How to Open & Run in Android Studio
1. Unzip this downloaded archive into your workspace folder:
   ```bash
   unzip jarvis-android-project.zip -d jarvis-android
   ```
2. Open Android Studio -> **File** -> **Open** -> select the `jarvis-android` folder.
3. Allow Gradle to sync dependencies.
4. Set `JARVIS_API_BASE_URL` in `app/build.gradle.kts` to your deployed HTTPS JARVIS backend URL. Keep Gemini and OpenJarvis provider keys on the backend only; never place them in `local.properties`, source code or the APK.
5. Select an Android Tablet emulator or physical Android device.
6. Click **Run** (`Shift + F10`) or build APK via **Build** -> **Build Bundle(s) / APK(s)** -> **Build APK(s)**.

---

### Key Subsystems Implemented
- **ArcReactor UI**: 60 FPS rotating vector concentric reactors with custom pulse shaders.
- **Voice HUD**: Visual-only placeholder; native speech recognition and background wake-word listening are not implemented.
- **Smart Facility UI**: Device-control UI scaffold; real Alexa/provider integration is not enabled until credentials, discovery and command execution are implemented.
- **Automations**: Empty placeholder screen; WorkManager scheduling and device triggers are not implemented. No external sensors are required.
- **Room Persistence**: Room database schema scaffold; memory screen is empty until persistence is wired into the UI.
- **OpenJarvis Connector**: Backend-proxied HTTP integration; configure the trusted endpoint on the server.
- **Alexa**: UI and setup scaffold only; real OAuth, request verification, discovery and device command bridge remain pending.
