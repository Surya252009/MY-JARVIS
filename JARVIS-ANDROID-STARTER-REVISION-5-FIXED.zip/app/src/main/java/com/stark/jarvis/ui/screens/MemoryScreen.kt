package com.stark.jarvis.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.unit.dp
import com.stark.jarvis.ui.theme.*

data class StoredMemory(val title: String, val category: String, val details: String)

@Composable
fun MemoryScreen() {
    val memories = remember { emptyList<StoredMemory>() }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(JarvisBlack)
            .padding(24.dp)
    ) {
        Text("PERSISTENT NEURAL MEMORY (ROOM DB)", color = JarvisCyan, style = MaterialTheme.typography.headlineMedium)
        Text("Memory storage and cloud sync are not implemented yet.", color = JarvisTextSecondary)
        Spacer(modifier = Modifier.height(20.dp))

        if (memories.isEmpty()) {
            Text("No saved memories", color = JarvisTextPrimary, style = MaterialTheme.typography.titleMedium)
        } else LazyColumn(verticalArrangement = Arrangement.spacedBy(16.dp)) {
            items(memories) { mem ->
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(12.dp))
                        .background(JarvisSurface)
                        .border(1.dp, JarvisSurfaceBorder, RoundedCornerShape(12.dp))
                        .padding(16.dp)
                ) {
                    Column {
                        Text(mem.title, color = JarvisCyan, style = MaterialTheme.typography.titleMedium)
                        Text("Category: ${mem.category}", color = JarvisTextSecondary, style = MaterialTheme.typography.bodySmall)
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(mem.details, color = JarvisTextPrimary, style = MaterialTheme.typography.bodyMedium)
                    }
                }
            }
        }
    }
}
