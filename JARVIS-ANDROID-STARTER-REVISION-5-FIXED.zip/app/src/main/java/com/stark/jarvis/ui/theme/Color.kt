package com.stark.jarvis.ui.theme

import androidx.compose.ui.graphics.Color

val JarvisCyan = Color(0xFF00F2FE)
val JarvisElectricBlue = Color(0xFF0EA5E9)
val JarvisDeepBlue = Color(0xFF03142C)
val JarvisBlack = Color(0xFF020617)
val JarvisSurface = Color(0x9908162D)
val JarvisSurfaceBorder = Color(0x3300F2FE)
val JarvisTextPrimary = Color(0xFFE2E8F0)
val JarvisTextSecondary = Color(0xFF94A3B8)
val JarvisAlert = Color(0xFFEF4444)
val JarvisSuccess = Color(0xFF10B981)
val JarvisWarning = Color(0xFFF59E0B)
