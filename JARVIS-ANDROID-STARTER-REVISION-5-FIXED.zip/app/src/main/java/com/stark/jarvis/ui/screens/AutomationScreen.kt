package com.stark.jarvis.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.unit.dp
import com.stark.jarvis.ui.theme.*

data class Routine(val name: String, val trigger: String, val actions: String, var enabled: Boolean)

@Composable
fun AutomationScreen() {
    var routines by remember { mutableStateOf(emptyList<Routine>()) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(JarvisBlack)
            .padding(24.dp)
    ) {
        Text("AUTOMATION ENGINE (WORKMANAGER)", color = JarvisCyan, style = MaterialTheme.typography.headlineMedium)
        Text("Automation scheduling is not connected yet. No routines are active.", color = JarvisTextSecondary)
        Spacer(modifier = Modifier.height(20.dp))

        if (routines.isEmpty()) {
            Text("No automations configured", color = JarvisTextPrimary, style = MaterialTheme.typography.titleMedium)
            Text("Create a real provider and scheduler integration before enabling routines.", color = JarvisTextSecondary)
        } else LazyColumn(verticalArrangement = Arrangement.spacedBy(16.dp)) {
            items(routines) { routine ->
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(12.dp))
                        .background(JarvisSurface)
                        .border(1.dp, JarvisSurfaceBorder, RoundedCornerShape(12.dp))
                        .padding(16.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(routine.name, color = JarvisCyan, style = MaterialTheme.typography.titleMedium)
                            Text("Trigger: ${routine.trigger}", color = JarvisTextPrimary, style = MaterialTheme.typography.bodyMedium)
                            Text("Actions: ${routine.actions}", color = JarvisTextSecondary, style = MaterialTheme.typography.bodySmall)
                        }
                        Switch(
                            checked = routine.enabled,
                            onCheckedChange = { newState ->
                                routines = routines.map { if (it.name == routine.name) it.copy(enabled = newState) else it }
                            }
                        )
                    }
                }
            }
        }
    }
}
