package com.stark.jarvis

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.ui.Modifier
import com.stark.jarvis.navigation.JarvisNavGraph
import com.stark.jarvis.ui.theme.JarvisBlack
import com.stark.jarvis.ui.theme.JARVISTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            JARVISTheme {
                Surface(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(JarvisBlack),
                    color = JarvisBlack
                ) {
                    JarvisNavGraph()
                }
            }
        }
    }
}
