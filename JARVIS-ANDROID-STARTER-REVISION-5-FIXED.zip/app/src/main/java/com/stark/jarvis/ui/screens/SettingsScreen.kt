package com.stark.jarvis.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.stark.jarvis.ui.theme.*

@Composable
fun SettingsScreen() {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(JarvisBlack)
            .padding(24.dp)
    ) {
        Text("SYSTEM SETTINGS & CLOUD BRIDGES", color = JarvisCyan, style = MaterialTheme.typography.headlineMedium)
        Spacer(modifier = Modifier.height(20.dp))

        Text("AI Engine Provider", color = JarvisCyan, style = MaterialTheme.typography.titleMedium)
        Text("Primary: Gemini (server-side proxy; backend URL and key must be configured)", color = JarvisTextPrimary)
        Spacer(modifier = Modifier.height(16.dp))

        Text("OpenJarvis endpoint and API key must be configured on the JARVIS backend host. The Android app does not store provider credentials.", color = JarvisTextSecondary)
        Spacer(modifier = Modifier.height(20.dp))

        Text("Amazon Alexa Smart Home Skill", color = JarvisCyan, style = MaterialTheme.typography.titleMedium)
        Text("Account Linking Status: NOT LINKED", color = JarvisTextPrimary)
        Text("Alexa OAuth and the Smart Home skill are not implemented in this starter. This screen cannot link an account or control devices.", color = JarvisTextSecondary)
    }
}
