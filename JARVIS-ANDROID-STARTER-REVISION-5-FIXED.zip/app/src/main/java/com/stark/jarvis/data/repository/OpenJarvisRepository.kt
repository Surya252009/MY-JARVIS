package com.stark.jarvis.data.repository

import com.stark.jarvis.BuildConfig
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.util.concurrent.TimeUnit

class OpenJarvisRepository {
    private val client = OkHttpClient.Builder()
        .connectTimeout(10, TimeUnit.SECONDS)
        .readTimeout(30, TimeUnit.SECONDS)
        .build()

    suspend fun checkHealth(): Boolean = withContext(Dispatchers.IO) {
        try {
            val baseUrl = BuildConfig.JARVIS_API_BASE_URL.trimEnd('/')
            val request = Request.Builder().url("$baseUrl/api/openjarvis/health")
                .post(JSONObject().toString().toRequestBody("application/json".toMediaType()))
                .build()
            client.newCall(request).execute().use { response ->
                response.isSuccessful && JSONObject(response.body?.string().orEmpty()).optBoolean("connected")
            }
        } catch (_: Exception) {
            false
        }
    }

    suspend fun sendQuery(prompt: String): String = withContext(Dispatchers.IO) {
        try {
            val baseUrl = BuildConfig.JARVIS_API_BASE_URL.trimEnd('/')
            val payload = JSONObject()
                .put("message", prompt)
                .put("model", "openjarvis/core-7b")
                .toString()
            val request = Request.Builder()
                .url("$baseUrl/api/openjarvis/chat")
                .post(payload.toRequestBody("application/json".toMediaType()))
                .build()
            client.newCall(request).execute().use { response ->
                val responseText = response.body?.string().orEmpty()
                if (!response.isSuccessful) throw IllegalStateException("JARVIS backend returned HTTP ${response.code}")
                JSONObject(responseText).optString("reply").ifBlank { "OpenJarvis returned an empty response." }
            }
        } catch (error: Exception) {
            "OpenJarvis connection error: ${error.localizedMessage ?: "Unknown error"}"
        }
    }
}
