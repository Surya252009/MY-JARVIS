package com.stark.jarvis.navigation

import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.navigation.compose.*
import com.stark.jarvis.ui.screens.*
import com.stark.jarvis.ui.theme.*

sealed class Screen(val route: String, val title: String, val icon: androidx.compose.ui.graphics.vector.ImageVector) {
    object Dashboard : Screen("dashboard", "Dashboard", Icons.Default.Dashboard)
    object Voice : Screen("voice", "Voice HUD", Icons.Default.Mic)
    object Chat : Screen("chat", "Brain", Icons.Default.Psychology)
    object SmartHome : Screen("smarthome", "Smart Home", Icons.Default.Home)
    object Automations : Screen("automations", "Automations", Icons.Default.AutoMode)
    object Memory : Screen("memory", "Memory", Icons.Default.Storage)
    object Settings : Screen("settings", "Settings", Icons.Default.Settings)
}

@Composable
fun JarvisNavGraph() {
    val navController = rememberNavController()
    val navBackStackEntry by navController.currentBackStackEntryAsState()
    val currentRoute = navBackStackEntry?.destination?.route ?: Screen.Dashboard.route

    Row(modifier = Modifier.fillMaxSize()) {
        // Futuristic Tablet Navigation Rail
        NavigationRail(
            containerColor = JarvisDeepBlue,
            contentColor = JarvisCyan,
            modifier = Modifier.width(80.dp)
        ) {
            val screens = listOf(
                Screen.Dashboard,
                Screen.Voice,
                Screen.Chat,
                Screen.SmartHome,
                Screen.Automations,
                Screen.Memory,
                Screen.Settings
            )
            screens.forEach { screen ->
                NavigationRailItem(
                    selected = currentRoute == screen.route,
                    onClick = {
                        if (currentRoute != screen.route) {
                            navController.navigate(screen.route) {
                                popUpTo(navController.graph.startDestinationId)
                                launchSingleTop = true
                            }
                        }
                    },
                    icon = { Icon(screen.icon, contentDescription = screen.title) },
                    label = { Text(screen.title, color = JarvisTextSecondary) },
                    colors = NavigationRailItemDefaults.colors(
                        selectedIconColor = JarvisCyan,
                        indicatorColor = JarvisCyan.copy(alpha = 0.2f),
                        unselectedIconColor = JarvisTextSecondary
                    )
                )
            }
        }

        NavHost(
            navController = navController,
            startDestination = Screen.Dashboard.route,
            modifier = Modifier.weight(1f)
        ) {
            composable(Screen.Dashboard.route) { DashboardScreen(navController) }
            composable(Screen.Voice.route) { VoiceAssistantScreen() }
            composable(Screen.Chat.route) { ChatScreen() }
            composable(Screen.SmartHome.route) { SmartHomeScreen() }
            composable(Screen.Automations.route) { AutomationScreen() }
            composable(Screen.Memory.route) { MemoryScreen() }
            composable(Screen.Settings.route) { SettingsScreen() }
        }
    }
}
