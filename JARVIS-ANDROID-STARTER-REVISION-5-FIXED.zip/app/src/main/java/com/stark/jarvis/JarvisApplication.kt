package com.stark.jarvis

import android.app.Application
import com.stark.jarvis.data.local.JarvisDatabase

class JarvisApplication : Application() {
    val database: JarvisDatabase by lazy { JarvisDatabase.getDatabase(this) }

    override fun onCreate() {
        super.onCreate()
        instance = this
    }

    companion object {
        lateinit var instance: JarvisApplication
            private set
    }
}
