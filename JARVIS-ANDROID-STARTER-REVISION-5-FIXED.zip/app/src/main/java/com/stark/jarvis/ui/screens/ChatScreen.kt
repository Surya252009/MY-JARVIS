package com.stark.jarvis.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Send
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.stark.jarvis.data.repository.GeminiRepository
import com.stark.jarvis.ui.theme.*
import kotlinx.coroutines.launch

 data class Message(val text: String, val isFromJarvis: Boolean)

@Composable
fun ChatScreen() {
    var messages by remember { mutableStateOf(emptyList<Message>()) }
    var inputText by remember { mutableStateOf("") }
    var isSending by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()
    val repository = remember { GeminiRepository() }

    Column(
        modifier = Modifier.fillMaxSize().background(JarvisBlack).padding(16.dp)
    ) {
        Text("AI NEURAL CORE", color = JarvisCyan, style = MaterialTheme.typography.headlineMedium)
        Text("Messages are sent to your configured JARVIS backend.", color = JarvisTextSecondary)
        Spacer(modifier = Modifier.height(16.dp))

        LazyColumn(
            modifier = Modifier.weight(1f).fillMaxWidth(),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            items(messages) { msg ->
                val bg = if (msg.isFromJarvis) JarvisSurface else JarvisCyan.copy(alpha = 0.15f)
                val alignment = if (msg.isFromJarvis) Arrangement.Start else Arrangement.End
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = alignment) {
                    Surface(color = bg, shape = RoundedCornerShape(12.dp), modifier = Modifier.widthIn(max = 500.dp)) {
                        Text(text = msg.text, color = JarvisTextPrimary, modifier = Modifier.padding(14.dp))
                    }
                }
            }
            if (isSending) item { Text("J.A.R.V.I.S. is thinking…", color = JarvisCyan) }
        }

        Row(modifier = Modifier.fillMaxWidth().padding(top = 12.dp)) {
            OutlinedTextField(
                value = inputText,
                onValueChange = { if (it.length <= 20000) inputText = it },
                placeholder = { Text("Enter a message…", color = JarvisTextSecondary) },
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = JarvisCyan,
                    unfocusedBorderColor = JarvisSurfaceBorder,
                    focusedTextColor = JarvisTextPrimary
                ),
                modifier = Modifier.weight(1f),
                enabled = !isSending
            )
            Spacer(modifier = Modifier.width(8.dp))
            IconButton(
                enabled = inputText.isNotBlank() && !isSending,
                onClick = {
                    val query = inputText.trim()
                    if (query.isNotEmpty()) {
                        messages = messages + Message(query, false)
                        inputText = ""
                        isSending = true
                        scope.launch {
                            val reply = repository.generateResponse(query)
                            messages = messages + Message(reply, true)
                            isSending = false
                        }
                    }
                },
                modifier = Modifier.size(56.dp)
            ) {
                Icon(Icons.Default.Send, contentDescription = "Send", tint = JarvisCyan)
            }
        }
    }
}
