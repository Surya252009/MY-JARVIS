package com.stark.jarvis.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.MicOff
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.stark.jarvis.ui.components.ArcReactor
import com.stark.jarvis.ui.components.ReactorState
import com.stark.jarvis.ui.theme.*

@Composable
fun VoiceAssistantScreen() {
    var transcript by remember { mutableStateOf("Native speech recognition is not connected in this build.") }
    var responseText by remember { mutableStateOf("Use the chat screen for live AI responses.") }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(JarvisBlack)
            .padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.SpaceBetween
    ) {
        Text("VOICE INTERFACE HUD", color = JarvisCyan, style = MaterialTheme.typography.headlineMedium)

        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            ArcReactor(
                state = ReactorState.IDLE,
                size = 300
            )
            Spacer(modifier = Modifier.height(24.dp))
            Text(
                text = "VOICE INPUT NOT CONFIGURED",
                color = JarvisTextSecondary,
                style = MaterialTheme.typography.titleMedium
            )
        }

        Column(
            modifier = Modifier.fillMaxWidth(0.8f),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(text = transcript, color = JarvisTextPrimary, style = MaterialTheme.typography.bodyLarge)
            Spacer(modifier = Modifier.height(8.dp))
            Text(text = responseText, color = JarvisCyan, style = MaterialTheme.typography.bodyMedium)
            Spacer(modifier = Modifier.height(24.dp))

            IconButton(
                onClick = {},
                enabled = false,
                modifier = Modifier
                    .size(72.dp)
                    .background(JarvisCyan.copy(alpha = 0.2f), CircleShape)
            ) {
                Icon(
                    imageVector = Icons.Default.MicOff,
                    contentDescription = "Voice recognition unavailable",
                    tint = JarvisTextSecondary,
                    modifier = Modifier.size(36.dp)
                )
            }
        }
    }
}
