package com.stark.jarvis.data.repository

import com.stark.jarvis.BuildConfig
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.util.concurrent.TimeUnit

class GeminiRepository {
    private val client = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .build()

    suspend fun generateResponse(prompt: String): String = withContext(Dispatchers.IO) {
        val baseUrl = BuildConfig.JARVIS_API_BASE_URL.trimEnd('/')
        require(baseUrl.startsWith("https://")) {
            "Configure a valid HTTPS JARVIS backend URL in app/build.gradle.kts."
        }
        try {
            val payload = JSONObject().put("message", prompt).toString()
            val body = payload.toRequestBody("application/json".toMediaType())
            val request = Request.Builder()
                .url("$baseUrl/api/chat")
                .post(body)
                .build()

            client.newCall(request).execute().use { response ->
                val responseText = response.body?.string().orEmpty()
                if (!response.isSuccessful) {
                    throw IllegalStateException("JARVIS backend returned HTTP ${response.code}")
                }
                val reply = JSONObject(responseText).optString("reply")
                if (reply.isBlank()) throw IllegalStateException("JARVIS backend returned an empty reply.")
                reply
            }
        } catch (error: Exception) {
            "JARVIS connection error: ${error.localizedMessage ?: "Unknown error"}"
        }
    }
}
